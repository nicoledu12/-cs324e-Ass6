# -cs324e-Ass6
Simulation:

Download the file and allow the computer to create a folder to store the processing files in. Following this click play and the user should see snow falling. The snow can also be moved with a force based on the mouse location. If the user moves the mouse around they should see the snow around the mouse being repelled.

The second item the user should see are the fireworks which follow the laws of gravity and also explode to imitate the image of a firework.

The last item is the fire on the bottom right hand corner. This fire employs anti-gravity force to show the smoke billowing. To make this interactive the user can directly click on the fire to initiate a brief moment of sparks.
